<?php

function xmldb_auth_pam_install() {
    global $CFG, $DB;

}
