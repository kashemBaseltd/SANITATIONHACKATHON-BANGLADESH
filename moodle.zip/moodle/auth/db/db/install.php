<?php

function xmldb_auth_db_install() {
    global $CFG, $DB;

}
