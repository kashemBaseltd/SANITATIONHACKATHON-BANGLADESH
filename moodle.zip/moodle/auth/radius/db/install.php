<?php

function xmldb_auth_radius_install() {
    global $CFG, $DB;

}
